# AI/DevOps: Predykcja obciążenia LSTM + trigger Ansible

## Co robi ten projekt?

- Generuje symulowane dane obciążenia CPU.
- Wykrywa anomalie (Isolation Forest).
- Trenuje LSTM do predykcji kolejnego obciążenia.
- Symuluje wywołanie playbooka Ansible, jeśli prognozowane obciążenie przekracza próg.
- Wszystko wizualizuje na wykresie.

## Jak uruchomić?

1. `pip install -r requirements.txt`
2. `python main_lstm_ansible.py`
3. Sprawdź konsolę i wykres. Jeśli prognoza CPU > 60, zobaczysz symulację wywołania Ansible.

## Pliki

- `main_lstm_ansible.py` – cały pipeline
- `requirements.txt` – zależności
- `README.md` – to, co właśnie czytasz

Możesz używać w PyCharm, Datalore, VSCode itp.
