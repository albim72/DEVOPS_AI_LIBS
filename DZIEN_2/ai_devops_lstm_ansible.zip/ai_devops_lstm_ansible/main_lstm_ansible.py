import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import IsolationForest
import datetime

# --- 1. Generowanie danych
np.random.seed(42)
time = pd.date_range("2025-07-22 08:00:00", periods=500, freq="T")
cpu_load = np.sin(np.linspace(0, 20, 500)) * 10 + 50 + np.random.normal(0, 2, 500)
df = pd.DataFrame({'timestamp': time, 'cpu_load': cpu_load})

# --- 2. Wykrywanie anomalii (Isolation Forest)
iso = IsolationForest(contamination=0.03)
df['anomaly'] = iso.fit_predict(df[['cpu_load']])
anomalies = df[df['anomaly'] == -1]

# --- 3. Przygotowanie danych dla LSTM
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

scaler = MinMaxScaler()
cpu_scaled = scaler.fit_transform(df[['cpu_load']])

def create_sequences(data, seq_length):
    xs, ys = [], []
    for i in range(len(data) - seq_length):
        x = data[i:(i + seq_length)]
        y = data[i + seq_length]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

SEQ_LEN = 20
X, y = create_sequences(cpu_scaled, SEQ_LEN)
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

# --- 4. Budowa i trening LSTM
model = Sequential([
    LSTM(32, input_shape=(SEQ_LEN, 1)),
    Dense(1)
])
model.compile(optimizer='adam', loss='mse')
history = model.fit(X_train, y_train, epochs=10, batch_size=16, validation_data=(X_test, y_test), verbose=1)

# --- 5. Predykcja i decyzja
last_seq = cpu_scaled[-SEQ_LEN:]
last_seq = last_seq.reshape((1, SEQ_LEN, 1))
future_pred = model.predict(last_seq)
future_pred_rescaled = scaler.inverse_transform(future_pred)[0][0]
if future_pred_rescaled > 60:
    decision = True
else:
    decision = False

print(f"Prognozowane obciążenie CPU (LSTM): {future_pred_rescaled:.2f}")
print("Decyzja: Skaluj!" if decision else "Decyzja: Nie skaluj")

# --- 6. Symulacja wywołania Ansible
def trigger_ansible(playbook, extra_vars=None):
    print(f"[{datetime.datetime.now()}] Wywołuję Ansible playbook: {playbook}")
    if extra_vars:
        print(f"Z parametrami: {extra_vars}")

if decision:
    trigger_ansible("scale_up.yml", {"cpu": f"{future_pred_rescaled:.2f}"})
else:
    print(f"[{datetime.datetime.now()}] Skalowanie nie jest wymagane.")

msg = f"[{datetime.datetime.now()}] [ChatOps BOT]: Prognoza LSTM = {future_pred_rescaled:.2f}. Decyzja: {'Skaluj' if decision else 'Nie skaluj'}."
print(msg)

# --- 7. Wizualizacja
plt.figure(figsize=(12,6))
plt.plot(df['timestamp'], df['cpu_load'], label='CPU Load')
plt.scatter(anomalies['timestamp'], anomalies['cpu_load'], color='red', label='Anomaly')
plt.scatter(df['timestamp'].iloc[-1] + pd.Timedelta(minutes=1), future_pred_rescaled, color='green', label='LSTM forecast', s=100)
plt.xlabel("Czas")
plt.ylabel("Obciążenie CPU (%)")
plt.legend()
plt.title("LSTM — predykcja + wykrywanie anomalii + trigger Ansible")
plt.tight_layout()
plt.show()
