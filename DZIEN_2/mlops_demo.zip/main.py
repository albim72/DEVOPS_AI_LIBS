from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import joblib

app = FastAPI()
model = joblib.load("model.joblib")

class IrisFeatures(BaseModel):
    data: list

@app.post("/predict")
def predict(features: IrisFeatures):
    X = np.array(features.data).reshape(1, -1)
    prediction = int(model.predict(X)[0])
    return {"prediction": prediction}
