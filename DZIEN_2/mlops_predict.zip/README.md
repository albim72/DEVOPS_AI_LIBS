# MLOps Minimal Demo — Iris + FastAPI

## Szybki start

1. **Trening modelu**
    ```
    python train.py
    ```

2. **Uruchom serwis FastAPI**
    ```
    uvicorn main:app --reload
    ```

3. **Testowanie predykcji (np. curl lub Postman)**
    ```
    curl -X POST "http://127.0.0.1:8000/predict" -H "Content-Type: application/json" -d "{\"data\": [5.1, 3.5, 1.4, 0.2]}"
    ```

4. **Konteneryzacja (Docker)**
    ```
    docker build -t iris-mlops-demo .
    docker run -p 8000:8000 iris-mlops-demo
    ```

---

## Pliki w projekcie
- train.py — trening i zapis modelu
- main.py — REST API z FastAPI
- requirements.txt — zależności
- Dockerfile — uruchomienie jako kontener
