import requests

import requests
from requests.exceptions import ConnectionError


def make_prediction(data):
    url = "http://localhost:8080/predict"
    payload = {"data": data}

    try:
        response = requests.post(url, json=payload, timeout=5)
        return response.json()
    except ConnectionError:
        print("Błąd połączenia! Sprawdź czy:")
        print("1. Serwer jest uruchomiony na localhost:8000")
        print("2. Port 8000 jest zajęty przez inną aplikację")
        return None
    except requests.exceptions.Timeout:
        print("Przekroczono czas oczekiwania na odpowiedź")
        return None
    except Exception as e:
        print(f"Wystąpił nieoczekiwany błąd: {str(e)}")
        return None


# Przykładowe dane
input_data = [5.1, 3.5, 1.4, 0.2]
result = make_prediction(input_data)

if result:
    print("Otrzymana predykcja:", result)